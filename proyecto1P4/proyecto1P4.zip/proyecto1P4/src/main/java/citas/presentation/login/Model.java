/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package citas.presentation.login;


import citas.logic.Paciente;



public class Model {
    Paciente user;
    
    public Model(){
        this.user = new Paciente();
    }
    
    public Paciente getUser() {
        return user;
    }

    public void setUser(Paciente user) {
        this.user = user;
    }
    
    
    
}
